package org.flowvisor.exceptions;

public class MalformedControllerURL extends FVException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public MalformedControllerURL(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

}
