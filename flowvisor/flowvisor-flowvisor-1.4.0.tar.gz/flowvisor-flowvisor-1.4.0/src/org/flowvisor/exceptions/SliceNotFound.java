package org.flowvisor.exceptions;

public class SliceNotFound extends FVException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public SliceNotFound(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

}
