package org.flowvisor.exceptions;

public class SliceNameDisallowedException extends Exception {
	public SliceNameDisallowedException(String err) {
		super(err);
	}
}
