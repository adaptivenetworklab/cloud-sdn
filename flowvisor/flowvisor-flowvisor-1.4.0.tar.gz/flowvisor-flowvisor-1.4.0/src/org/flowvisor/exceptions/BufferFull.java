package org.flowvisor.exceptions;

import java.io.IOException;

public class BufferFull extends IOException {

	public BufferFull(String string) {
		super(string);
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
