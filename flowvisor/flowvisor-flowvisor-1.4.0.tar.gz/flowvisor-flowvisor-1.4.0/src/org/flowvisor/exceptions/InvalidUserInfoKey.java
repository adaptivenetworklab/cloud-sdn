package org.flowvisor.exceptions;

public class InvalidUserInfoKey extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public InvalidUserInfoKey(String s) {
		super(s);
	}

}
