package org.flowvisor.exceptions;

public class MalformedOFMessage extends Exception {

	public MalformedOFMessage(String string) {
		super(string);
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
