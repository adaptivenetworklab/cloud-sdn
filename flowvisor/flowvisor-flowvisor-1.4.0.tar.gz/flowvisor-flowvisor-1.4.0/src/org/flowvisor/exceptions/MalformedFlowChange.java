package org.flowvisor.exceptions;

public class MalformedFlowChange extends FVException {

	public MalformedFlowChange(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
