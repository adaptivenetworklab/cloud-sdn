package org.flowvisor.exceptions;

public class PermissionDeniedException extends FVException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public PermissionDeniedException(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

}
