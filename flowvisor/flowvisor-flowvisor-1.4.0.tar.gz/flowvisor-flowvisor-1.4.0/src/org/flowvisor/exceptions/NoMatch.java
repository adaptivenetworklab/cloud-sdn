/**
 *
 */
package org.flowvisor.exceptions;

/**
 * @author capveg
 *
 */
public class NoMatch extends FVException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public NoMatch(String str) {
		super(str);
	}

}
