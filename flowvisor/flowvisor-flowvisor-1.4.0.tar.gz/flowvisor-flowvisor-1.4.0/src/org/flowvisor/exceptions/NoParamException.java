package org.flowvisor.exceptions;

public class NoParamException extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public NoParamException(String err) {
		super(err);
	}
}
