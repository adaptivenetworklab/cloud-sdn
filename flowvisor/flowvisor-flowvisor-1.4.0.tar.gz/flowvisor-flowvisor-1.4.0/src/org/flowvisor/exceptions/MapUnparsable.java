package org.flowvisor.exceptions;

public class MapUnparsable extends FVException {

	public MapUnparsable(String err) {
		super(err);
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
