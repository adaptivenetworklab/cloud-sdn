package org.flowvisor.exceptions;

public class UnknownMatchField extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public UnknownMatchField(String str) {
		super(str);
	}

}
