package org.flowvisor.exceptions;

public class FVException extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = -4548551349904898191L;

	public FVException(String err) {
		super(err);
	}

}
