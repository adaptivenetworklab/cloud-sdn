/**
 *
 */
package org.flowvisor.config;

/**
 * @author capveg
 *
 */
public class ConfigError extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public ConfigError(String err) {
		super(err);
	}

}
