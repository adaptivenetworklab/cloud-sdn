package org.flowvisor.config;

import org.flowvisor.exceptions.FVException;

public class InvalidDropPolicy extends FVException {

	public InvalidDropPolicy(String err) {
		super(err);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
