/**
 *
 */
package org.flowvisor.config.convertor;

/**
 * @author capveg
 *
 */
public class ConfigWrongTypeError extends ConfigError {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param err
	 */
	public ConfigWrongTypeError(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

}
