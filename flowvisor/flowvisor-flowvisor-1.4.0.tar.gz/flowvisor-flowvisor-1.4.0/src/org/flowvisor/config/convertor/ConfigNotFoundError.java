/**
 *
 */
package org.flowvisor.config.convertor;
/**
 * @author capveg
 *
 */
public class ConfigNotFoundError extends ConfigError {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public ConfigNotFoundError(String err) {
		super(err);
	}

}
