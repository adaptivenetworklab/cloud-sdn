/**
 *
 */
package org.flowvisor.config.convertor;
/**
 * @author capveg
 *
 */
public class ConfigCantCreateError extends ConfigError {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param err
	 */
	public ConfigCantCreateError(String err) {
		super(err);
		// TODO Auto-generated constructor stub
	}

}
